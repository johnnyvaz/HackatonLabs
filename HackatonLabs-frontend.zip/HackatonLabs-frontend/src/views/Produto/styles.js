import styled from 'styled-components';

export const Image = styled.img`
    width: 80%;
    height: auto;
    margin: 10px auto;
`;
export const Preco = styled.span`
   font-size: 10vw;
   text-align: center;
   color: #000;
`;
