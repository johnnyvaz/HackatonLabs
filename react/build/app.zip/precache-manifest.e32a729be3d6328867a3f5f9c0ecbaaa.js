self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2f54db2e7af7ce68166530726c4fdc94",
    "url": "/index.html"
  },
  {
    "revision": "1410d1f69e0a0d9900bd",
    "url": "/static/css/2.266e55a5.chunk.css"
  },
  {
    "revision": "1410d1f69e0a0d9900bd",
    "url": "/static/js/2.06088f68.chunk.js"
  },
  {
    "revision": "bab1405d5b7c3b8c5ea3",
    "url": "/static/js/main.bb5cbc09.chunk.js"
  },
  {
    "revision": "5bf52c7e4b90ea71311b",
    "url": "/static/js/runtime~main.afda575c.js"
  }
]);